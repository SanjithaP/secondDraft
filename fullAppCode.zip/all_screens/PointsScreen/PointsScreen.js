import React, { Component } from "react";
import { StyleSheet, View, TextInput, ScrollView, TouchableOpacity, Text } from "react-native";
import { Dimensions } from 'react-native';
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;


global.globalDesiredTasksArray = [
  {
    pointValue: "15",
    activity: "Test"
  }
]


function  PointsScreen () {

  return (
    <ScrollView style={styles.container}> 

   
      <Text>Did you complete your tasks for the day?</Text>

      {global.globalDesiredTasksArray.map((screenObject, i, activityList) =>(
        <View style={styles.screenBreakListContainer}>
        <View style={styles.pointValueContainer}>
          <Text style={styles.textStyle}>{screenObject.pointValue}</Text>
         </View>
              
        <View style={styles.middleContainer}>
          <Text style={styles.textStyle}>{screenObject.activity}</Text>
        </View>  
        
          <View style = {styles.buttonContainer}>
 
            <View style = {styles.innerButtonContainer}>
            <TouchableOpacity 
              style = {styles.redButton}
              onPress = {() => {
                global.globalDesiredTasksArray.splice(i, 1);
              }}
            >
              <Text style = {styles.buttonText}>Pop</Text>
            </TouchableOpacity>

              </View>
            </View>
            </View>
      ))}

      </ScrollView>

  );
  
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  screenBreakListContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: 'white',
    backgroundColor: '#D3FAFF',
 },
 pointValueContainer: {
    flex: 1,
    height: 75,
    alignItems: 'center',
    justifyContent: 'center'
 },
 middleContainer: {
    flex: 1,
    margin: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center'
 },
 redButton: {
  backgroundColor: "red",
  justifyContent: "center",
  alignItems: "center",
  margin: 10,
  borderRadius: 10,
  height: windowHeight/10,

},
buttonText: {
  color: 'white',
  fontSize: 14
},
innerButtonContainer: {
  flex: 1
},
buttonContainer: {
  flex: 1,
  flexDirection: 'row'
},
});

export default PointsScreen;
