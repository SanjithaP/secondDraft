import React, { Component } from "react";
import { StyleSheet, View, TextInput, ScrollView, TouchableOpacity, Text } from "react-native";
import CupertinoButtonPurple2 from "../components/CupertinoButtonPurple2";

class  SettingsScreen extends React.Component {

  static navigationOptions = {
    title: 'Calendar' 
  };

  render() {
  return (
    <ScrollView style={styles.container}>

      <TextInput
        placeholder="Editable Text"
        style={styles.textInput}
      ></TextInput>

      <CupertinoButtonPurple2
        style={styles.cupertinoButtonPurple2}
      ></CupertinoButtonPurple2>

      <TouchableOpacity><Text>Sign In With Google</Text></TouchableOpacity>
      
    </ScrollView>
  );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  cupertinoButtonPurple2: {
    height: 54,
    width: 175,
    marginTop: 282,
    alignSelf: "center"
  },
  textInput: {
    fontFamily: "Arial",
    color: "#121212",
    fontSize: 28,
    width: 166,
    height: 33,
    marginTop: 54,
    marginLeft: 105
  }
});

export default SettingsScreen;
